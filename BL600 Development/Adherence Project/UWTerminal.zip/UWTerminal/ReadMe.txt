**************************
Laird Technologies 2013
**************************

UwTerminal.Exe is Laird's Terminal Emulation Utility to interact and download 
smartBASIC applications to a Laird Module.

    Unless otherwise informed Laird Modules are shipped in factory default
    state and so will be set to communicate with uart settings 9600,N,8,1
    or 115200,N,8,1

XComp_*.Exe files are cross compilers for Laird modules. If UwTerminal.exe is
launched from this folder, then it will be able to resolve the correct cross
compiler for the appropriate firmware version in the module you are working
with

Tip: You can determine the firmware version a cross compiler relates to by
     invoking the .exe with a /I command line argument.
     
Xcompilers:-

XComp_BL600r2_8CF9_450E.exe  ==> v1.5.70.0
XComp_BL600r2_41DC_882B.exe  ==> v1.5.69.0
XComp_BL600r2_5F28_4E2B.exe  ==> v1.5.62.0
XComp_BL600r2_4E68_C700.exe  ==> v1.3.57.0
XComp_BL600r2_CA0D_1DA6.exe  ==> v1.2.54.0
XComp_BL600r2_D24D_8092.exe  ==> v1.1.50.0
     
